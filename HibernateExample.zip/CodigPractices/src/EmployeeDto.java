
public class EmployeeDto {
	private String id;
	private Double salary;
	
	public EmployeeDto(String id, Double sal) {
		this.id= id;
		this.salary=sal;
	}
	public EmployeeDto() {
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + "]";
	}
	
}
