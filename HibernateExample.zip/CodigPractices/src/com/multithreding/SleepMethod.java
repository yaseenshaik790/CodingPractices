package com.multithreding;

public class SleepMethod extends Thread{
	
	public void run() {
		
		try {
			
			for(int i=0; i< 5; i++) {
				Thread.sleep(5000);
				System.out.println(" i");
			}
		}catch (InterruptedException e) {
			System.out.println(" Exception");
		}
	}
	
	public static void main(String[] args) {
		SleepMethod method = new SleepMethod();
		SleepMethod sleepMethod = new SleepMethod();
		method.start();
		sleepMethod.start();
	}
}
