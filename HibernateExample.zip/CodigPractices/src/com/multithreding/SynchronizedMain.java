package com.multithreding;

class Table {
	public Object table;

	public synchronized void run(String sub) {
		try {
			for (int i = 10; i <= 15; i++) {
				Thread.sleep(2000);
				System.out.println(i+sub);
			}
		} catch (InterruptedException e) {
			System.out.println("// TODO: handle exception");
		}
	}
}

class Physics extends Thread{
	Table table;

	Physics(Table table) {
		this.table =table;
	}
	
	public void run() {
		table.run(" Physics");
	}

}

class Maths extends Thread{
	Table table;

	Maths(Table table) {
		this.table =table;
	}
	
	public void run() {
		table.run(" maths");
	}

}

class SynchronizedMain {

	public static void main(String[] args) {
		
		Table table = new Table();
		Physics physics = new Physics(table);
		Maths maths = new  Maths(table);
		physics.start();
		maths.start();

	}
}
