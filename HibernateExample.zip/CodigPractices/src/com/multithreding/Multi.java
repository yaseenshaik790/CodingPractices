package com.multithreding;

class Multi extends Thread {

	public void run() {
		System.out.println("Thread is running");
	}

	public static void main(String[] args) {
		Multi multi = new Multi();
		multi.start();

	}
}

class MultiRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println(" Thresd is running");

	}

	public static void main(String[] args) {
		Multi multi = new Multi();
		Thread thread = new Thread(multi);
		thread.start();

	}

}
