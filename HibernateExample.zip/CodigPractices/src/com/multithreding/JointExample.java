package com.multithreding;

//joint will wait until other thread to die.
public class JointExample extends Thread {

	public void run() {
		try {
			
			for(int i=1; i<= 5; i++) {
				Thread.sleep(2000);
				System.out.println(i);
			}
		}catch (InterruptedException e) {
			System.out.println(" Exception");
		}
	}
	public static void main(String[] args) {
		JointExample example = new JointExample();
		JointExample example2 = new JointExample();
		JointExample example3 = new JointExample();
		example.start();
		
		try {
			example.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		example2.start();
		example3.start();
	}
}
