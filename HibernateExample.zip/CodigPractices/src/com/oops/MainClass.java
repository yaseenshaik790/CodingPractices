package com.oops;

//Encapsulation: Protecting the data members to restrict directly accessing those variables. through setters & getters only accessable
//Aquiring the properties from super class to sub class is called inheritance
//Perfomarming multiple operations in different ways
public class MainClass extends Car {

	public static void main(String[] args) {
		
		Vehicle car =  new Car();
		Vehicle truck = new Truck();
		System.out.println(car.drive(Car.class.getName()));
		System.out.println(truck.drive(Truck.class.getName()));
	}
}
