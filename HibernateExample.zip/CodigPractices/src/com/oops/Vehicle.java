package com.oops;

public class Vehicle {

	private Car car;
	private Truck truck;
	
	
	public Vehicle() {
		super();
	}

	public Car getCar() {
		return car;
	}

	public void setCar(Car car) {
		this.car = car;
	}

	public Truck getTruck() {
		return truck;
	}

	public void setTruck(Truck truck) {
		this.truck = truck;
	}
	
	public String drive(String vehicle) {
		return " Drive: "+vehicle;
	}
}
