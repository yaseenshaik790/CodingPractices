package com.exceptionhandlin.v2;

class InvalidAgeException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public InvalidAgeException(String message) {
		super(message);
	}
}
public class CustomExceptionHandling {
	
	public void getAge(Integer age) throws InvalidAgeException {
		if(age > 10) {
			System.out.println(" Acceess");
		}else {
			throw new InvalidAgeException("Invalid Age: "+ age);
		}
	}
	
	public static void main(String[] args) throws InvalidAgeException {
		
		CustomExceptionHandling custom = new CustomExceptionHandling();
		custom.getAge(0);
	}
}
