package com.multi.v2;

//Thread life cycle > New > Runnable> Running > No-Runnable > Terminate
//Thread can be created by extending the Thread or implementing the Runnable interface
//start() --> to create new thread
//run() --> to execute the class if any thread running on it
class Employee extends Thread{
	
	public void run() {
		System.out.println("Create Thread");
	}
}
class CreatingThread {
	
	public static void main(String[] args) {
		Customer employee = new Customer();
		employee.start();
	}
}
