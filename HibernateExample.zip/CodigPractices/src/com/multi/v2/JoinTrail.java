package com.multi.v2;
/**
 * 
 * @author YASEEN
 * 
 * Join method waits to die the execution thread and then it will allow to start next thread
 *
 */
class Vehicle extends Thread{
	
	public void run() {
		try {
			for(int i=1; i<= 3; i++) {
				Thread.sleep(2000);
				System.out.println("Vehicle "+i);
			}
			
		}catch (InterruptedException e) {
			// TODO: handle exception
		}
	}
}

class JoinTrail {
	
	public static void main(String[] args) throws InterruptedException {
		
		Vehicle vehicle = new Vehicle();
		System.out.println(" Before assigning name "+ vehicle.getName());
		Vehicle vehicle2 = new Vehicle();
		vehicle.start();
		vehicle.join();
		vehicle2.start();	
		vehicle.setName("Vehicle");
		System.out.println(" After assigning name "+ vehicle.getName());
		
	}
}
