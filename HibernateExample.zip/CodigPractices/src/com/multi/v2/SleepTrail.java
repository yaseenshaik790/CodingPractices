package com.multi.v2;


//sleep() will make thread sleep for certain time period
class Customer extends Thread{
	
	public void run() {
		try {
			System.out.println("Count starts");
			Thread.sleep(2000);
			System.out.println("Count sleeps");
		}catch (InterruptedException e) {
			// TODO: handle exception
		}
	}
}
class SleepTrail {
	
	public static void main(String[] args) {
		Customer customer = new Customer();
		customer.start();
		/**
		 * We cannot start Thread two time it will through java.lang.IllegalThreadStateException
		 */
		//customer.start();
	}
}
