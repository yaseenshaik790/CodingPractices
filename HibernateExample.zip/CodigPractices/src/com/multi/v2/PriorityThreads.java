package com.multi.v2;

class Food extends Thread{
	
	public void run() {
		try {
			for(int i=1; i<= 3; i++) {
				Thread.sleep(2000);
				System.out.println("Food "+i);
			}
			
		}catch (InterruptedException e) {
			// TODO: handle exception
		}
	}
}
class Hotel extends Thread{
	
	public void run() {
		try {
			for(int i=1; i<= 3; i++) {
				Thread.sleep(2000);
				System.out.println("Hotel "+i);
			}
			
		}catch (InterruptedException e) {
			// TODO: handle exception
		}
	}
}
class PriorityThreads {
	public static void main(String[] args) {
		Food food = new Food();
		Food food2 = new Food();
		Hotel hotel = new Hotel();
		food.setPriority(Thread.MIN_PRIORITY);
		food2.setPriority(Thread.MAX_PRIORITY);
		hotel.setPriority(Thread.NORM_PRIORITY);
		food.start();
		food2.start();
		hotel.start();
		
	}
}
