package com.collections.v2;

import java.util.LinkedList;

public class LinkedListExample {
	
	public static void main(String[] args) {
		
		LinkedList<Integer> integers = new LinkedList<>();
		integers.add(1);
		integers.add(2);
		integers.add(3);
		
		integers.add(1, 22);
		System.out.println(integers);
		
	}

}
