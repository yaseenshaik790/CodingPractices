package com.collections.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 
 * @author YASEEN	
 * 
 * stream: to manupulate a group of collection obj or to process collection objes
 * filter: to filter the collection objests based upon the conditions
 * stream: to chnage the object state or manupulating objects from one obj to another obj
 *
 */
public class StreamsAPI {

	public static void main(String[] args) {
		Employee employee = new Employee(1, "Yaseen", 20000.0);
		Employee employee2 = new Employee(2, "Bellamy", 25000.0);
		Employee employee3 = new Employee(3, "Clark", 30000.0);
		Employee employee4 = new Employee(4, "Octav", 1000.0);
		List<Employee> employees = new ArrayList<Employee>();
		employees.add(employee);
		employees.add(employee2);
		employees.add(employee3);
		employees.add(employee4);
		
		List<Employee> moreThanTwoThousandSal = employees.stream().filter(e -> e.getSalary()>= 2000).collect(Collectors.toList());
		System.out.println("moreThanTwoThousandSal: ");
		for(Employee emp: moreThanTwoThousandSal) {
			System.out.println(emp);
		}
		
		List<EmployeeDto> dtos = employees.stream().map((Employee emp) ->{
			EmployeeDto employeeDto = new EmployeeDto(emp.getId(),emp.getName(),emp.getSalary());
			return employeeDto;
		}).collect(Collectors.toList());
		System.out.println("converting obj to obj : ");
		for(EmployeeDto dto: dtos) {
			System.out.println(dto);
		}
		
		List<Integer> integers = new ArrayList<Integer>();
		integers.add(10);
		integers.add(50);
		integers.add(30);
		integers.add(20);
		integers.add(40);
		
		List<Integer> sortAsc = integers.stream().sorted().collect(Collectors.toList());
		System.out.println("Ascending Order: "+ sortAsc);
		List<Integer> sortDesc = integers.stream().sorted((i1, i2) -> i2.compareTo(i1)).collect(Collectors.toList());
		System.out.println("Desc Order: "+ sortDesc);
		
		Integer maxValue = integers.stream().max((i1, i2) -> i2.compareTo(i1)).get();
		System.out.println("Max value "+ maxValue);
		
		Integer minValue = integers.stream().min((i1, i2) -> i2.compareTo(i1)).get();
		System.out.println("Min value "+ minValue);
		
	}
}
