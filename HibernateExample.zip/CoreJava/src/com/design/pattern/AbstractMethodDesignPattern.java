package com.design.pattern;

public class AbstractMethodDesignPattern {

	public static void main(String[] args) {
		
	}
}
