package com.design.pattern;

public class Loan {

}
