package com.design.pattern;

public class Bank {

}
