package com.star.pattern;

interface Jav{
	public static void get() {
		System.out.println("Hi");
	}
}
public class Trials implements Jav{
	
	/*
	 * static { System.out.println("Hi"); }
	 */
	public static void main(String[] args) {
		Jav.get();
	}
}
