package com.star.pattern;

class StarPatternMain {
	/**
	 * * * * * * * @ * * * * *
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if ((i == 3) && (j == 2)) {
					System.out.print("@ ");
				} else {
					System.out.print("* ");
				}
			}
			System.out.println();
		}
	}
}

class Dem {
	/**
	 * * * * * * * * *
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if ((i == 1) || (j == 1) || (i == 4) || (j == 4)) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}

class Jack {
	/**
	 * * * * * * * * *
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if ((i == 1) || (j == 1) || (i == 4) || (j == 4)) {
					System.out.print("*");
				} else if (i == j) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}

class Ja {
	/**
	 * * * * * * * * *
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if (i <= j) {
					System.out.print("*");
				} else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
}

class Hasr {
	/**
	 * * * * * * * * *
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int space = 3;
		int count = 1;
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= 4; j++) {
				if (i <= space)
					System.out.print(" ");
				else
					System.out.print("*");
			}
			space--;
			System.out.println();
		}
	}
}

class Multi {

	public static void main(String[] args) {
		int space = 4;
		int star = 1;
		for (int i = 1; i <= 4; i++) {
			for (int j = 1; j <= space; j++) {
				System.out.print(" ");
			}
			for (int k = 1; k <= star; k++) {
				System.out.print("*");
			}
			System.out.println();
			space --;
			star +=2;
		}
		
	}
}