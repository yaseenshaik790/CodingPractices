package com.star.pattern;

interface Bank {

	public String getBankName();
}

class AxisBank implements Bank {

	private static String name;

	AxisBank() {
		name = "Axis Bank";
	}

	@Override
	public String getBankName() {
		return name;

	}
}

class IngBank implements Bank {

	private static String name;

	IngBank() {
		name = "Ing Bank";
	}

	@Override
	public String getBankName() {
		return name;

	}
}

abstract class Loan {
	protected double rate;

	public abstract void getRate(double r);

	public void calculateEmi(int years, int amount) {
		System.out.println("Loan amount: " + amount + " EMI: " + years * rate);
	}
}

class HomeLoan extends Loan {

	@Override
	public void getRate(double r) {
		// TODO Auto-generated method stub
		rate = r;
	}
}

class CarLoan extends Loan {

	@Override
	public void getRate(double r) {
		// TODO Auto-generated method stub
		rate = r;
	}
}

abstract class AbstractFactoryMethods {
	public abstract Bank getBankName(String name);

	public abstract Loan getLoan(String name);
}

class LoanFactory extends AbstractFactoryMethods {

	@Override
	public Bank getBankName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Loan getLoan(String name) {
		if (name.equals("Home"))
			return new HomeLoan();
		else if (name.equals("Car"))
			return new CarLoan();
		else
			return null;
	}
}

class BankFactory extends AbstractFactoryMethods {

	@Override
	public Bank getBankName(String name) {
		if (name.equals("Axis"))
			return new AxisBank();
		else if (name.equals("Ing"))
			return new IngBank();
		else
			return null;
	}

	@Override
	public Loan getLoan(String name) {
		// TODO Auto-generated method stub
		return null;
	}
}
class FactoryCreator{
	
	public static AbstractFactoryMethods getFactory(String name) {
		if(name.equals("Bank")) {
			return new BankFactory();
		}else if(name.equals("Loan")) {
			return new LoanFactory();
		}else{
			return null;
		}
	}
}
class AbstractFactoryPattern {
	
	public static void main(String[] args) {
		
		AbstractFactoryMethods factoryCeator = FactoryCreator.getFactory("Bank");
		Bank bank = factoryCeator.getBankName("Axis");
		System.out.println(bank.getBankName());
		
		AbstractFactoryMethods loanFactory = FactoryCreator.getFactory("Loan");
		Loan loan = loanFactory.getLoan("Car");
		loan.getRate(10.0);
		loan.calculateEmi(10, 10);
		
	}
}
