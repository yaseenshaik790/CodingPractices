package com.telusko.design.patters;

class Phone {
	private String phoneName;
	private Double price;
	private String brand;

	public Phone(String phoneName, Double price, String brand) {
		super();
		this.phoneName = phoneName;
		this.price = price;
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Phone [phoneName=" + phoneName + ", price=" + price + ", brand=" + brand + "]";
	}

}

class PhoneBuilder {
	private String phoneName;
	private Double price;
	private String brand;

	public PhoneBuilder withPhoneName(String phoneName) {
		this.phoneName = phoneName;
		return this;
	}

	public PhoneBuilder withPrice(Double price) {
		this.price = price;
		return this;
	}

	public PhoneBuilder withBrand(String brand) {
		this.brand = brand;
		return this;
	}

	public Phone getPhone() {
		return new Phone(phoneName, price, brand);
	}
}

public class BuilderPatternExample {

	public static void main(String[] args) {
		Phone phone = new PhoneBuilder().withBrand("Lenova").getPhone();
		System.out.println(phone);
	}
}
