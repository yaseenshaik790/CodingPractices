package com.telusko.design.patters;

interface Pen {
	void write(String msg);
}

class CelloPen implements Pen {

	@Override
	public void write(String msg) {
		System.out.println(msg + " For CelloPhone");
	}

}

class BluePen implements Pen {

	@Override
	public void write(String msg) {
		System.out.println(msg + " For Blue Pen");
	}

}

class AdapterPen {

	private Pen p;

	public Pen getP() {
		return p;
	}

	public void setP(Pen p) {
		this.p = p;
	}

	public void writeAssignment(String msg) {
		p.write(msg);
	}
}

public class AdapterDesignPatternExample {

	public static void main(String[] args) {
		AdapterPen adapterPen = new AdapterPen();
		adapterPen.setP(new CelloPen());
		Pen p =new CelloPen();
		
		adapterPen.writeAssignment("Writing Pen Assinment!");
		
		CelloPen celloPen = (CelloPen) p;
		celloPen.write("Write");
		
		//adapterPen.setP(new CelloPen());
		//adapterPen.setP(new BluePen());
		//adapterPen.writeAssignment("Writing Pen Assinment!");

	}
}
