package com.telusko.design.patters;

interface OS {
	void spec();
}

class Windows implements OS {

	@Override
	public void spec() {
		System.out.println("Windowss Running...");

	}

}

class Mac implements OS {

	@Override
	public void spec() {
		System.out.println("Mac Running...");

	}

}

class Linux implements OS {

	@Override
	public void spec() {
		System.out.println("Lnux Running...");

	}

}

class OSFactoryMethodPatters {
	public OS getOperatingSystem(String st) {

		if (st.equals("Mac"))
			return new Mac();
		else if (st.equals("Windows"))
			return new Windows();
		else
			return new Linux();
	}
}

public class FactoryDesignPattern {
	public static void main(String[] args) {
		//We can hide the implem frm user and if we want to create new 
		OSFactoryMethodPatters factoryMethod = new OSFactoryMethodPatters();
		OS os = factoryMethod.getOperatingSystem("Mac");
		os.spec();
	}
}
