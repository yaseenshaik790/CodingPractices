package com.oops;

class Shape {
	void getArea() {
		System.out.println("Get Shape Area");
	}
}

class Rect extends Shape {
	void getArea() {
		System.out.println("Get Rect Area");
	}
}

class Tria extends Shape {
	void getArea() {
		System.out.println("Get Tria Area");
	}
}

class PloymorphismExampl {

	public static void main(String[] args) {
		Shape sh = new Shape();
		sh.getArea();
		Shape rec = new Rect();
		rec.getArea();
		Rect recSHa = (Rect) rec;
		recSHa.getArea();
		// Shape tri = new Tria();
		// sh.getArea();
		// rec.getArea();
		// tri.getArea();
	}
}
