package com.collections.v2;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class HashSetVsTreeSet {
	
	public static void main(String[] args) {
		String s1 = "Yaseen";
		String s2 =" L ";
		
		System.out.println(s1+s2);
		
		TreeSet<String> treeset = new TreeSet<String>();
	      treeset.add("Good");
	      treeset.add("For");
	      treeset.add("Health");
	     // treeset.add(null);//Nullpointer
	      
	      System.out.println(treeset);
	      
	      Hashtable<String, String> h = new Hashtable<>();
	      //h.put(null, null);
	      System.out.println(h);
		 
	      
	      HashMap<String, String> hm = new HashMap<>(); //override if more key nulls
	      hm.put(null, "kk");
	      hm.put(null, "ee");
	      System.out.println(hm);
	      
	      List<Integer> list = Arrays.asList(1,2,1,4);
	      
	      Set<Integer> sets = list.stream().collect(Collectors.toSet());
	      System.out.println(sets);
	      
	}
}
