package com.serializable;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DeserializationExec {
	
	public static void main(String[] args) throws ClassNotFoundException, IOException {
		//Student student = new Student(1, "Yaseen");
		FileInputStream fileInputStream = new FileInputStream("C:\\Users\\REHMAN\\Documents\\test.txt");
		ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);
		
		Student st = (Student) inputStream.readObject();
		
		System.out.println(st.id +" "+st.name);
	}
}
