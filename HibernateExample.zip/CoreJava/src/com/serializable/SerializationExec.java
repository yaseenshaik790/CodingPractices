package com.serializable;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int id;
	String name;
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
}
public class SerializationExec {
	
	public static void main(String[] args) throws IOException {
		
		Student student = new Student(1, "Yaseen");
		FileOutputStream fileOutputStream = new FileOutputStream("C:\\Users\\REHMAN\\Documents\\test.txt");
		ObjectOutputStream stream = new ObjectOutputStream(fileOutputStream);
		stream.writeObject(student);
		stream.flush();
		fileOutputStream.close();
		System.out.println(" Success");
		
	}
}
