package com.sky.design.patterns;

abstract class Bank{
	
	protected double rate;
	
	public abstract void getRate();
	
	public void calculateRate(int units) {
		System.out.println((units * rate));
	}
}
class AxisBank extends Bank{

	@Override
	public void getRate() {
		rate = 10;
	}
}
class HdfcBank extends Bank{

	@Override
	public void getRate() {
		rate = 20;
	}
}

class FactoryMethodPattern {
	
	public static void main(String[] args) {
		Bank axisBank = new AxisBank();
		axisBank.getRate();
		axisBank.calculateRate(10);
		
		Bank hdfc = new HdfcBank();
		hdfc.getRate();
		hdfc.calculateRate(10);
	}
}
