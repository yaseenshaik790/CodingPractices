package com.multi.v2;

public class MultiThreadingPS {

	public static void main(String[] args) {

		Thread t1 = new Thread("Publicis");
		Thread t2 = new Thread("Publicis");
		Thread t3 = new Thread("Publicis");
		runThread(t1, t2, t3);
	}

	public static void runThread(Thread t1,Thread t2, Thread t3) {
		
		/*
		 * synchronized (t) { t.sta System.out.println(t.getName()); }
		 */
	}

}
