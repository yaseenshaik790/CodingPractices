package com.multi.v2;


class Car extends Thread{
	public void run() {
		
		if(Thread.currentThread().isDaemon()) {
			System.out.println(" is daemon thread...");
		}else {
			System.out.println(" User Thread");
		}
	}
}
/** 
 * 
 * @author YASEEN
 * Before starting thread only we have define daemon otherwise it will throw java.lang.IllegalThreadStateException
 * 
 * Its just supporter thread for user threads. It will execute on thread priorities
 *
 */
class DaemonThreadTrail {

	public static void main(String[] args) {
		Car car = new Car();
		Car car2 = new Car();
		Car car3 = new Car();
		car.setDaemon(true);
		car.start();
		car2.setDaemon(true);
		car2.start();
		car3.start();
	}
}
