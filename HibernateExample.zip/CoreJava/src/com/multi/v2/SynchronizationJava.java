package com.multi.v2;

class Transcation {

	/*
	 * public synchronized void make(String value) { for (int i = 1; i <= 2; i++) {
	 * try { Thread.sleep(2000); } catch (InterruptedException e) {
	 * e.printStackTrace(); } System.out.println(value + " Transcation " + i); } }
	 */
	
	public void makeTransaction(String value) {
		System.out.println("Starting...");
		
		synchronized (this) {
			
			for (int i = 1; i <= 2; i++) {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println(value + " Transcation " + i);
			}
		}
		System.out.println("Ending...");
	}
}

class Money extends Thread {
	Transcation transcation;

	public Money(Transcation transcation) {
		this.transcation = transcation;
	}

	public void run() {
		//transcation.make("Money");
		transcation.makeTransaction("Money");
	}
}

class Debit extends Thread {
	Transcation transcation;

	public Debit(Transcation transcation) {
		this.transcation = transcation;
	}

	public void run() {
		//transcation.make("Debit");
		transcation.makeTransaction("Debit");
	}
}

class SynchronizationJava {

	public static void main(String[] args) {
		Transcation transcation = new Transcation();
		Money money = new Money(transcation);
		Debit debit = new Debit(transcation);
		money.start();
		debit.start();
	}
}
