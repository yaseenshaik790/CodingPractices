package com.java8;

class A{
	public void get() {
		System.out.println(" A: get");
	}
}
class B extends A{
	public void get() {
		System.out.println(" B: get");
	}
}
class D extends B{
	public void get() {
		System.out.println(" D: get");
	}
}
public class HirarchilevelInheritanceJava extends A {
	
	public static void main(String[] args) {
		HirarchilevelInheritanceJava h = new HirarchilevelInheritanceJava();
		h.get();
	}
}
