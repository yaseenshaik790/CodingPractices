package com.java8;

abstract class Shape{
	public abstract void getAria();
	
}
class Tria extends Shape{
	int length;
	int width;
	
	Tria(int length, int width){
		this.length = length;
		this.width = width;
	}
	
	@Override
	public void getAria() {
		System.out.println(length + width);
		
	}

}
class Circle extends Shape{
	final static double pi = 3.14;
	int radius;
	Circle(int radius){
		this.radius = radius;
	}
	
	@Override
	public void getAria() {
		System.out.println(" Circle "+(pi* radius*radius));
		
	}
}
class Rect extends Shape{

	@Override
	public void getAria() {
		System.out.println(" Rect");
		
	}
}
public class ShapeMainMethos {
	
	public static void main(String[] args) {
		Circle sh = new Circle(10);
		sh.getAria();
	}
}
