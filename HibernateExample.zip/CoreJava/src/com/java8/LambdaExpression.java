package com.java8;

interface Bank {
	void draw();
}
interface Shapes{
	String getRet();
	
	
}
interface Name{
	String getName(String name);
}
interface Add{
	int add(int a, int b);
}
class LambdaExpression {

	public static void main(String[] args) {

		int rate = 2;
		//with ananymouse class
		Bank b = new Bank() {
			public void draw() {
				System.out.println("Bank " + rate);
			}
		};
		
		b.draw();
		
		//with only method ()
		
		Bank b1 = () ->{
			System.out.println("Bank b1" + rate);
		};
		b1.draw();
		
		//with Return type
		
		Shapes s = () -> {
			return "With Rtur";
		};
		System.out.println(s.getRet());
		
		
		//with name
		Name n =  name ->{
			return "Hi "+ name;
		};
		System.out.println(n.getName("Yaseen"));
		
		Name n2 =  (name) ->{
			return "Hi "+ name;
		};
		System.out.println(n2.getName("Shaik"));
		
		
	}
}
