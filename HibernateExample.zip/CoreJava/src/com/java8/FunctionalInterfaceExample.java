package com.java8;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class FunctionalInterfaceExample {

	static void print(String msg) {
		System.out.println(msg);
	}

	public static boolean verify(int a) {
		if (a == 1)
			return true;
		else
			return false;
	}

	public static String getMesage(String msg) {
		return msg;
	}

	public static void main(String[] args) {
		// Consumer
		 Consumer<String> consumer = FunctionalInterfaceExample::print;
		 consumer.accept("Consumer");
		 
		 //Predicate
		 Predicate<Integer> predicate = FunctionalInterfaceExample::verify;
		 boolean b = predicate.test(1);
		 
		 System.out.println(b);
		 
		 //Function
		 Function<String, String>  function= FunctionalInterfaceExample::getMesage;
		 String output = function.apply("Yaseen");
		 System.out.println(output);
	}

}
