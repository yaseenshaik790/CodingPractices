package com.java8;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionSorting {
	
	public static void main(String[] args) {
		Map<Integer,String> map = new HashMap<Integer, String>();
		map.put(1, "Yaseen");
		map.put(5, "Harsha");
		map.put(2, "Jack");
		
		Set<Integer> list = map.keySet();
		
		Iterator<Integer> it = list.iterator();
		Map<Integer,String> output = new HashMap<Integer, String>();
		while(it.hasNext()) {
			
		}
	}
}
