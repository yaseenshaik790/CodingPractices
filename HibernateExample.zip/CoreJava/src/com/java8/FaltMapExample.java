package com.java8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class Emp{
	int id;
	int name;
	
	public Emp(int id, int name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + "]";
	}
	
}
public class FaltMapExample {
	
	public static void main(String[] args) {
		
		//List
		Emp emp = new Emp(1, 3);
		Emp emp1 = new Emp(1, 4);
		Emp emp2 = new Emp(1, 5);
		
		List<Emp> emps = Arrays.asList(emp,emp1,emp2);
		List<Emp> emps1 = Arrays.asList(emp,emp1,emp2);
		List<Emp> emps2 = Arrays.asList(emp,emp1,emp2);
		
		List<List<Emp>>  list = Arrays.asList(emps,emps1,emps2);
		
		List<Emp> out = list.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
		System.out.println(out);
		//Array
		 String[][] dataArray = new String[][]{{"a", "b"}, {"c", "d"}, {"e", "f"}, {"g", "h"}};
		 
		 List<String> output = Arrays.stream(dataArray).flatMap(x-> Arrays.stream(x)).collect(Collectors.toList());
		 System.out.println(output);
		
	}

}
