package com.java8;

import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

class Product implements Comparable<Product> {
	Integer id;
	String name;
	Double cost;

	public Product(Integer id, String name, Double cost) {
		super();
		this.id = id;
		this.name = name;
		this.cost = cost;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", cost=" + cost + "]";
	}

	@Override
	public int compareTo(Product p) {
		if (p.getCost() == cost) {
			return 0;
		} else if (p.getCost() > cost) {
			return 1;
		} else {
			return -1;
		}
	}

}

public class Sreams {

	public static void main(String[] args) {

		Product p1 = new Product(1, "Jack", 222.3);
		Product p2 = new Product(2, "k", 22.3);
		Product p3 = new Product(5, "Jck", 722.3);
		Product p4 = new Product(3, "Jack", 322.3);
		List<Product> products = Arrays.asList(p1, p2, p3, p4);

		List<Integer> ints = new ArrayList<>();
		ints.add(2);
		ints.add(22);
		ints.add(2);
		ints.add(22);
		ints.add(3);
		// Grouping By

        Map<Integer, Long> gb = ints.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(gb);

		// get product cost more than 300
		List<Double> cost = products.stream().filter(p -> p.getCost() > 300).map(p -> p.cost)
				.collect(Collectors.toList());
		System.out.println("Product Cost " + cost);

		// List product which is having more than 300
		List<Product> pr = products.stream().filter(p -> p.getCost() > 300).collect(Collectors.toList());
		System.out.println(pr);

		// Sort using
		List<Product> asc = products.stream().sorted().collect(Collectors.toList());
		System.out.println(asc);

		// Sort using comparartor
		List<Product> pro = products.stream().collect(Collectors.toList());
		System.out.println(pro);

		List<Product> pro1 = products.stream().sorted((pl, pq) -> pl.getCost().compareTo(pq.getCost()))
				.collect(Collectors.toList());
		System.out.println(pro1);

		List<Integer> intergers = new ArrayList<>();
		intergers.add(1);
		intergers.add(2);
		intergers.add(1);

		List<Integer> values = intergers.stream().distinct().collect(Collectors.toList());
		System.out.println(values);
	}
}
