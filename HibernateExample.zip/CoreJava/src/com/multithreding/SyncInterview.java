package com.multithreding;

class Synch implements Runnable{

	@Override
	public void run() {
		
		
	}
	
	
	
}

public class SyncInterview  {

	public static void main(String[] args) throws InterruptedException {
		Thread t1 = new Thread("Public");
		Thread t2 = new Thread("Sapient");
		Thread t3 = new Thread("Ltd");
		Thread t = new Thread();
		
		synchronized (t1) {
			t1.start();
			System.out.print(t1.getName()+" ");
			t2.start();
			System.out.print(t2.getName()+" ");
			t3.start();
			System.out.print(t3.getName());
		}
	}

	
}
