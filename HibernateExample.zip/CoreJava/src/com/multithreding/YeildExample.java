package com.multithreding;

class MyThread extends Thread {
	public void run() {
		for (int i = 0; i < 5; ++i) {
			Thread.yield(); // By calling this method, MyThread stop its execution and giving a chance to a
							// main thread
			System.out.println("Thread started: yeild " + Thread.currentThread().getName());
		}
		System.out.println("Thread ended: yeild " + Thread.currentThread().getName());
	}
}

public class YeildExample {
	public static void main(String[] args) {
		MyThread thread = new MyThread();
		thread.start();
		for (int i = 0; i < 5; ++i) {
			System.out.println("Thread started:" + Thread.currentThread().getName());
		}
		System.out.println("Thread ended:" + Thread.currentThread().getName());
	}
}