
public class Employee implements Comparable<Employee>{
	
	private String id;
	private Double salary;
	private int age;

	public Employee(String id, Double salary, int age) {
		super();
		this.id = id;
		this.salary = salary;
		this.age = age;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	

	@Override
	public String toString() {
		return "Employee [id=" + id + ", salary=" + salary + ", age=" + age + "]";
	}

	@Override
	public int compareTo(Employee emp) {
		if(age == emp.getAge()) {
			return 0;
		}else if(age > emp.getAge()) {
			return 1;
		}else {
			return -1;
		}
	}

}
