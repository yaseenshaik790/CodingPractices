
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ArrayMainClass {

	public static void main(String[] args) {
  
  
  
  String s ="A";
  
  String s1 = s+"7";
  System.out.println(s1);
  
  Employee employee = new Employee("1", 20.00,1); 
  Employee employee1 = new Employee("1", 25.00,1);
  Employee employee2 = new Employee("1", 30.00,1); 
  Employee  employee3 = new Employee("1", 50.00,1);
  
  List<Employee> employees = new ArrayList<Employee>();
  employees.add(employee3); employees.add(employee); employees.add(employee1);
  employees.add(employee2);
  
  
  //Sorting
  
  List<Employee> empSalary = employees.stream().filter(e -> e.getSalary()>=
  20).collect(Collectors.toList());
  
  for(Employee result: empSalary) { System.out.println(result); }
  
  List<EmployeeDto> dtos = employees.stream().map((Employee e) -> {
  
  EmployeeDto dto = new EmployeeDto(e.getId(), e.getSalary());
  
  return dto;
  }
  
  ).collect(Collectors.toList());
  
  System.out.println(" EMpl Dto "+dtos);
  
  //Using filter 
  List<Employee> list = employees.stream().filter( e ->
  e.getSalary() >= 25).collect(Collectors.toList()); 
  System.out.println(list);
  
  List<Integer> marks = new ArrayList<Integer>(); 
  marks.add(0); marks.add(10);
  marks.add(20); marks.add(25);
  
  //filter(Predicate p)
  List<Integer> resultOfAboveTen =
  marks.stream().filter(m -> m >= 10).collect(Collectors.toList());
  System.out.println(" Above 10 marks" + resultOfAboveTen);
  
  //map(Function f)
  List<Integer> addingFivemarks = marks.stream().map(m -> m +
  5).collect(Collectors.toList()); System.out.println(" addingFivemarks" +
  addingFivemarks);
  
  //Sorting
  List<Integer> sorting =
  marks.stream().sorted().collect(Collectors.toList());
  System.out.println(" normal sorting" + sorting);
  
  //ReversSorting 
  List<Integer> ReversSorting = marks.stream().sorted((i1, i2)
  -> i2.compareTo(i1)).collect(Collectors.toList());
  System.out.println(" ReversSorting" + ReversSorting);
  
  //Min 
  Integer min = marks.stream().min((i1, i2) -> i2.compareTo(i1)).get();
  System.out.println(" min" + min);
  
  //Max 
  Integer max = marks.stream().max((i1, i2) -> i2.compareTo(i1)).get();
  System.out.println(" max" + max);
  
  String i1 = "1";
  
  i1 += 1; System.out.println(i1);
  
  System.out.println(" Map to List");
  
  
  Map<String, String> m = new HashMap<String, String>();
  m.put("Hello",
  "World"); 
  m.put("Apple", "3.14"); m.put("Another", "Element");
  
  List<String> mapList = new ArrayList<String>(m.keySet()); 
  List<String> mapValues = new ArrayList<String>(m.values()); 
  for(String result: mapList) {
  System.out.println(result); }
  
  for(String resultValue: mapValues)
{ System.out.println(resultValue); } }

}
