package com.hibernates;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;

public class ExecutionMethod {

	public static void main(String[] args) {

		Customer customer = new Customer(1, "Harry", 250.0, 27, "USA");

		Configuration configuration = new Configuration().configure().addAnnotatedClass(Customer.class)
				.addAnnotatedClass(Student.class).addAnnotatedClass(Books.class);

		SessionFactory factory = configuration.buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		Books books = new Books();
		books.setBookId(1);
		books.setBookName("CSE");
		Student student = new Student();
		student.setId(1);
		student.setName("Yaseen");
		student.setBooks(books);

		Criteria cr = session.createCriteria(Customer.class);
		cr.addOrder(Order.desc("id"));
		cr.setFirstResult(1);
		cr.add(Restrictions.gt("salary", 200.0));
		cr.add(Restrictions.le("salary", 10));
		cr.setProjection(Projections.property("salary"));
		System.out.println(cr.list());
		// session.save(customer);

		session.save(student);

		transaction.commit();

		factory.close();

	}
}
